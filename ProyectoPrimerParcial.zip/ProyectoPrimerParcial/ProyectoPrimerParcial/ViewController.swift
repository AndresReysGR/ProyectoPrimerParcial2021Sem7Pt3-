//
//  ViewController.swift
//  ProyectoPrimerParcial
//
//  Created by Alumno on 9/15/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let secuenciaSerpienteVolteando = [
        UIImage(named: "Serpiente_1")!,
        UIImage(named: "Serpiente_2")!,
        UIImage(named: "Serpiente_3")!,
        UIImage(named: "Serpiente_4")!,
        UIImage(named: "Serpiente_5")!
    ]
    
    let secuenciaSerpienteBong = [
        UIImage(named: "SerpienteBong_1")!,
        UIImage(named: "SerpienteBong_2")!,
        UIImage(named: "SerpienteBong_3")!,
        UIImage(named: "SerpienteBong_4")!,
        UIImage(named: "SerpienteBong_5")!
    ]
    
    let secuenciaRata = [
        UIImage(named: "Rata_1")!,
        UIImage(named: "Rata_2")!,
        UIImage(named: "Rata_3")!,
        UIImage(named: "Rata_4")!,
        UIImage(named: "Rata_5")!
    ]
    
    let secuenciaRataQuesito = [
        UIImage(named: "RataQuesito_1")!,
        UIImage(named: "RataQuesito_2")!,
        UIImage(named: "RataQuesito_3")!,
        UIImage(named: "RataQuesito_4")!,
        UIImage(named: "RataQuesito_5")!
    ]
    
    let secuenciaHamster = [
        UIImage(named: "Hamster_1")!,
        UIImage(named: "Hamster_2")!,
        UIImage(named: "Hamster_3")!,
        UIImage(named: "Hamster_4")!,
        UIImage(named: "Hamster_5")!
    ]
    
    let secuenciaHamsterRodando = [
        UIImage(named: "HamsterRodando_1")!,
        UIImage(named: "HamsterRodando_2")!,
        UIImage(named: "HamsterRodando_3")!,
        UIImage(named: "HamsterRodando_4")!,
        UIImage(named: "HamsterRodando_5")!
    ]
    
    
   

    @IBOutlet weak var lblAnimales: UILabel!
    @IBOutlet weak var ImgAnimacionAnimales: UIImageView!
    @IBOutlet weak var ImgAnimacionConejo: UIImageView!
    @IBOutlet weak var ImgAnimacionRaton: UIImageView!
    @IBOutlet weak var ImgAnimacionHamster: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ImgAnimacionConejo.animationImages = secuenciaSerpienteVolteando
        ImgAnimacionConejo.animationDuration = 1.5
        ImgAnimacionConejo.startAnimating()
        
        ImgAnimacionRaton.animationImages = secuenciaRata
        ImgAnimacionRaton.animationDuration = 1.5
        ImgAnimacionRaton.startAnimating()
        
        ImgAnimacionHamster.animationImages = secuenciaHamster
        ImgAnimacionHamster.animationDuration = 1.5
        ImgAnimacionHamster.startAnimating()
        
        
    }
    
    @IBAction func doTapAnimarSerpiente(_ sender: Any) {
        ImgAnimacionAnimales.animationImages = secuenciaSerpienteBong
        ImgAnimacionAnimales.animationDuration = 1.5
        ImgAnimacionAnimales.startAnimating()
        
        lblAnimales.text = "Snake"
        
        
        
    }
    
    
    @IBAction func doTapRaton(_ sender: Any) {
        ImgAnimacionAnimales.animationImages = secuenciaRataQuesito
        ImgAnimacionAnimales.animationDuration = 1.5
        ImgAnimacionAnimales.startAnimating()
        
        lblAnimales.text = "Rat"
        
    }
    
    @IBAction func doTapHamster(_ sender: Any) {
        ImgAnimacionAnimales.animationImages = secuenciaHamsterRodando
        ImgAnimacionAnimales.animationDuration = 1.5
        ImgAnimacionAnimales.startAnimating()
        
        lblAnimales.text = "Hamster"
    }
    
    

}

